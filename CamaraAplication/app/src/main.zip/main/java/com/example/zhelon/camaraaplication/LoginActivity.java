package com.example.zhelon.camaraaplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText email, password;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.submit);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(email.getText().equals("") || password.getText().equals("")){
                    Toast.makeText(getApplicationContext(),"Ingrese campos", Toast.LENGTH_LONG).show();
                }else{
                    Intent intent = new Intent(getBaseContext(), MainActivity.class);
                    intent.putExtra("email", email.getText().toString());
                    Toast.makeText(getApplicationContext(),"Ingresando...", Toast.LENGTH_LONG).show();
                    finish();
                    startActivity(intent);

                }
            }
        });
    }
}
